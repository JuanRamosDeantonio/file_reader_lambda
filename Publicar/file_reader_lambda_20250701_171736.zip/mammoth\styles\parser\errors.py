class LineParseError(Exception):
    pass
